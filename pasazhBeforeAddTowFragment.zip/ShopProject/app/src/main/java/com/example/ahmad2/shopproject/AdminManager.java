package com.example.ahmad2.shopproject;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Environment;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.AppCompatTextView;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.widget.ImageView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class AdminManager extends MyActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private ViewPager viewPager;
    private FragmentAdapter adapter;
    private List<Fragment> fragmentList;
    private TabLayout tabLayout;
    private List<String> titleList;
    private Toolbar toolbar;
    private String user, userName;
    private AppCompatTextView txtNameHeader, txtEmailHeader;
    private ImageView imgHeader;
    private SharedPreferences preferences;
    private FragmentObjectListForAdmin fragmentObjectListForAdmin;
    private FragmentUserListForAdmin fragmentUserListForAdmin;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private String mobile;
    private Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_manager);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_admin_page);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout_adminPage);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.navi_view_adminPage);
        navigationView.setNavigationItemSelectedListener(this);


        getPreference();
        getSupportActionBar().setTitle(getString(R.string.hello)+" "+userName);
        toolbar.setSubtitle(getString(R.string.welcom_to_user));
        tabLayout = findViewById(R.id.tab_admin_page);
        fragmentList = new ArrayList<>();
        titleList = new ArrayList<>();
        viewPager = findViewById(R.id.pager_admin_page);
        fragmentUserListForAdmin = new FragmentUserListForAdmin();
        App.fragmentUserListForAdmin = fragmentUserListForAdmin;
        fragmentList.add(fragmentUserListForAdmin);
        titleList.add(getString(R.string.user_list));
        fragmentObjectListForAdmin = new FragmentObjectListForAdmin();
        App.fragmentObjectListForAdmin = fragmentObjectListForAdmin;
        fragmentList.add(fragmentObjectListForAdmin);
        titleList.add(getString(R.string.object_list));
        fragmentList.add(FragmentInsertObject.newInstance(fragmentObjectListForAdmin));
        titleList.add(getString(R.string.insert_object));
        FragmentOrderForAdmin fragmentOrderForAdmin = new FragmentOrderForAdmin();
        App.fragmentOrderForAdmin = fragmentOrderForAdmin;
        fragmentList.add(fragmentOrderForAdmin);
        titleList.add(getString(R.string.order_admin));
        adapter = new FragmentAdapter(getSupportFragmentManager(), fragmentList, titleList);
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
//        tabLayout.getTabAt(0).setIcon(ContextCompat.getDrawable(this, R.drawable.ic_action_user));
//        tabLayout.getTabAt(1).setIcon(ContextCompat.getDrawable(this, R.drawable.ic_object));
//        tabLayout.getTabAt(2).setIcon(ContextCompat.getDrawable(this, R.drawable.ic_add));
//        tabLayout.getTabAt(3).setIcon(ContextCompat.getDrawable(this, R.drawable.ic_order));
//        Log.i("tagposition",String.valueOf(viewPager.getAdapter().getItemPosition(FragmentObjectListForAdmin.class)));
//                    case "اضافه کردن کالا": {
//                        FragmentInsertObject fragmentInsertObject = (FragmentInsertObject) viewPager.getAdapter().instantiateItem(viewPager, i);
//                        fragmentInsertObject.getSpinner();
//                    }
//        drawerLayout =(DrawerLayout) findViewById(R.id.drawer_layout_adminPage);
//        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_drawer, R.string.close_drawer);
//        drawerLayout.addDrawerListener(toggle);
//        toggle.syncState();
//
//        navigationView = (NavigationView) findViewById(R.id.navi_view_adminPage);
//        navigationView.setNavigationItemSelectedListener(this);
        View headerView = navigationView.getHeaderView(0);
        txtEmailHeader = headerView.findViewById(R.id.txt_email_hedear);
        txtNameHeader = headerView.findViewById(R.id.txt_name_hedear);
        imgHeader = headerView.findViewById(R.id.img_header);
        imgHeader.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bitmap=getBitmap();
                if (bitmap!=null){
                    Dialog imgDialog=new Dialog(AdminManager.this);
                    imgDialog.setContentView(R.layout.layout_image_dialog);
                    changeSize(imgDialog.getWindow());
                    ImageView img=imgDialog.findViewById(R.id.img_dialog);
                    img.setImageBitmap(bitmap);
                    imgDialog.show();
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout_adminPage);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.admin_manager, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.item_edit_pass_admin) {
            Intent intent = new Intent(AdminManager.this, EditPassword.class);
            startActivity(intent);
        } else if (id == R.id.item_info_admin) {
            Intent intent = new Intent(AdminManager.this, EditUserInformationActivity.class);
            startActivity(intent);
        } else if (id == R.id.item_exit_admin) {
            finish();
        } else if (id == R.id.item_select_pic_admin) {
            Intent intent=new Intent(AdminManager.this,SelectImageProfile.class);
            startActivity(intent);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout_adminPage);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        setHeader();
    }

    private void changeSize(Window window) {
        Point size=new Point();
        getWindowManager().getDefaultDisplay().getSize(size);
        window.setLayout((int)(size.x*0.8),(int)(size.y*0.5));
    }

    private void setHeader() {
        getPreference();
        txtNameHeader.setText(userName);
        txtEmailHeader.setText(mobile);
        bitmap=getBitmap();
        if (bitmap != null) {
            imgHeader.setImageBitmap(bitmap);
        }
    }

    private Bitmap getBitmap() {
        Bitmap bmp;
        File subDir = new File(Environment.getExternalStorageDirectory(), "ShopDirPic");
        File file = new File(subDir, "myPic.jpg");
        if (file.exists()) {
            try {
                FileInputStream fileInputStream = new FileInputStream(file);
                bmp = BitmapFactory.decodeStream(fileInputStream);
                return bmp;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    private void getPreference() {
        preferences = getSharedPreferences("userInfoPre", MODE_PRIVATE);
        if (preferences!=null){
            userName=preferences.getString("name","");
            user=preferences.getString("user","");
            mobile=preferences.getString("mobile","");
        }
    }
}
