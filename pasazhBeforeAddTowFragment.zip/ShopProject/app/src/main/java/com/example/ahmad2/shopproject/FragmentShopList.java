package com.example.ahmad2.shopproject;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class FragmentShopList extends Fragment {

    private RecyclerView recyclerView;
    private ShopListAdapter adapter;
    private SearchView srchShop;
    private ProgressBar progBar;
    private MyItemDecoration itemDecoration;
    private List<Shop> shopList;
    private SharedPreferences preferences;
    private String token,user;



    public static FragmentShopList newInstance(){
        FragmentShopList fragmentShopList=new FragmentShopList();
        Bundle arg=new Bundle();
        fragmentShopList.setArguments(arg);
        return fragmentShopList;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle arguments = getArguments();
        preferences=getContext().getSharedPreferences("userInfoPre",Context.MODE_PRIVATE);
        token=preferences.getString("token","");
        user=preferences.getString("user","");
        itemDecoration=new MyItemDecoration(getContext(),LinearLayoutManager.VERTICAL);

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.layout_shop_list,container,false);
        recyclerView=view.findViewById(R.id.recycler_shop_list);
        srchShop=view.findViewById(R.id.srch_view_shop_list);
        progBar=view.findViewById(R.id.prog_shop_list);
        getShopList();
        return view;
    }

    private void getShopList() {
        progBar.setVisibility(View.VISIBLE);
        shopList=new ArrayList<>();
        OkHttpClient.Builder clientbuilder=new OkHttpClient.Builder();
        clientbuilder.addInterceptor(new Interceptor() {
            @Override
            public Response intercept(Chain chain) throws IOException {
                Request orginal = chain.request();
                Request request=orginal.newBuilder()
                        .addHeader("Content-Type","application/json")
                        .addHeader("shop-token",token)
                        .method(orginal.method(),orginal.body())
                        .build();
                return chain.proceed(request);
            }
        });
        OkHttpClient client=clientbuilder.build();
        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(App.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        RetrofitService retrofitService=retrofit.create(RetrofitService.class);
        final Login login=new Login();
        login.user=user;
        Call<ResponseShopListToken> call = retrofitService.getShopList(login);
        call.enqueue(new Callback<ResponseShopListToken>() {
            @Override
            public void onResponse(Call<ResponseShopListToken> call, retrofit2.Response<ResponseShopListToken> response) {
                progBar.setVisibility(View.INVISIBLE);
                if (response.isSuccessful()){
                    SharedPreferences.Editor editor=preferences.edit();
                    editor.putString("token",response.body().token);
                    editor.apply();
                    shopList=response.body().shopList;
                    showList();
                }
            }

            @Override
            public void onFailure(Call<ResponseShopListToken> call, Throwable t) {
                progBar.setVisibility(View.INVISIBLE);
                Toast.makeText(getContext(), getContext().getResources().getString(R.string.warrning_error), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void showList(){
        recyclerView.addItemDecoration(itemDecoration);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.VERTICAL,false));
        adapter=new ShopListAdapter(getActivity(), getContext(), shopList, new ShopListAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Shop shop) {

            }
        });
        recyclerView.setAdapter(adapter);
    }
}
