package com.example.ahmad2.shopproject;

public class RequestUserApiKey {

    public User user;
    public ApiKey apiKey=new ApiKey();
}
