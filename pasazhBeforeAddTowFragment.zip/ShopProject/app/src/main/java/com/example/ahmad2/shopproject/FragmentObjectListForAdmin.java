package com.example.ahmad2.shopproject;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.Gson;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class FragmentObjectListForAdmin extends Fragment {

    private ObjectListAdapter adapter;
    private List<ObjectInfo> objectList;
    private App app;
    private ProgressBar progBar;
    private SearchView srchView;
    private RecyclerView recyclerView;
    private SharedPreferences preferences;
    private String user;
    private String token;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferences = getContext().getSharedPreferences("userInfoPre", Context.MODE_PRIVATE);
        token = preferences.getString("token", "");
        user = preferences.getString("user", "");
        app = new App(getContext());
        if (objectList == null) {
            objectList = new ArrayList<>();
        }

    }

//    @Override
//    public void onResume() {
//        super.onResume();
//        getObjectList();
//        Toast.makeText(getContext(), "ok", Toast.LENGTH_SHORT).show();
//
//    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_object_list_for_admin, container, false);
        recyclerView = view.findViewById(R.id.recycler_list_admin);
        progBar = view.findViewById(R.id.prog_list_admin);
        getObjectList();
        srchView = view.findViewById(R.id.srch_view_list_admin);
        srchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(final String newText) {
                progBar.setVisibility(View.VISIBLE);
                if (newText.equals("")) {
                    getObjectList();
                    return false;
                }
                OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder();
                clientBuilder.addInterceptor(new Interceptor() {
                    @Override
                    public okhttp3.Response intercept(Chain chain) throws IOException {
                        okhttp3.Request orginal = chain.request();
                        okhttp3.Request request = orginal.newBuilder()
                                .addHeader("Content-Type", "application/json")
                                .addHeader("shop-token", token)
                                .build();
                        return chain.proceed(request);
                    }
                });
                OkHttpClient client = clientBuilder.build();
                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl(App.BASE_URL)
                        .addConverterFactory(GsonConverterFactory.create())
                        .client(client)
                        .build();
                RetrofitService retrofitService = retrofit.create(RetrofitService.class);
                Login login = new Login();
                login.user = user;
                login.pass=newText;
                Call<ResponseObjectListToken> call = retrofitService.getObjectListBySearch(login);
                call.enqueue(new Callback<ResponseObjectListToken>() {
                    @Override
                    public void onResponse(Call<ResponseObjectListToken> call, retrofit2.Response<ResponseObjectListToken> response) {
                        progBar.setVisibility(View.INVISIBLE);
                        if (response.isSuccessful()) {
                            SharedPreferences.Editor editor=preferences.edit();
                            editor.putString("token",response.body().token);
                            editor.apply();
                            objectList = response.body().objectList;
                            showList();
                        }
                    }

                    @Override
                    public void onFailure(Call<ResponseObjectListToken> call, Throwable t) {
                        progBar.setVisibility(View.INVISIBLE);
                        Toast.makeText(getContext(), getContext().getResources().getString(R.string.warrning_error), Toast.LENGTH_SHORT).show();
                    }
                });


//                StringRequest searchObjectRequest = new StringRequest(Request.Method.POST, App.SEARCH_OBJECT_FOR_ADMIN_URI,
//                        new Response.Listener<String>() {
//                            @Override
//                            public void onResponse(String response) {
//                                progBar.setVisibility(View.INVISIBLE);
//                                objectList = JsonParserForObject.getObjectList(response);
//                                showList();
//                            }
//                        }, new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        progBar.setVisibility(View.INVISIBLE);
//                        Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
//
//                    }
//                }) {
//                    @Override
//                    protected Map<String, String> getParams() throws AuthFailureError {
//                        Map<String, String> params = new HashMap<>();
//                        params.put("srch", newText);
//                        return params;
//                    }
//                };
//                app.getRequestQueue().add(searchObjectRequest);
                return false;
            }
        });
        return view;
    }

    public void getObjectList() {
        progBar.setVisibility(View.VISIBLE);
        OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder();
        clientBuilder.addInterceptor(new Interceptor() {
            @Override
            public okhttp3.Response intercept(Chain chain) throws IOException {
                okhttp3.Request orginal = chain.request();
                okhttp3.Request request = orginal.newBuilder()
                        .addHeader("Content-Type", "application/json")
                        .addHeader("shop-token", token)
                        .build();
                return chain.proceed(request);
            }
        });
        OkHttpClient client = clientBuilder.build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(App.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        RetrofitService retrofitService = retrofit.create(RetrofitService.class);
        Login login = new Login();
        login.user = user;
        Call<ResponseObjectListToken> call = retrofitService.getObjectList(login);
        call.enqueue(new Callback<ResponseObjectListToken>() {
            @Override
            public void onResponse(Call<ResponseObjectListToken> call, retrofit2.Response<ResponseObjectListToken> response) {
                progBar.setVisibility(View.INVISIBLE);
                if (response.isSuccessful()) {
                    SharedPreferences.Editor editor=preferences.edit();
                    editor.putString("token",response.body().token);
                    editor.apply();
                    objectList = response.body().objectList;
                    showList();
                }
            }

            @Override
            public void onFailure(Call<ResponseObjectListToken> call, Throwable t) {
                progBar.setVisibility(View.INVISIBLE);
                Toast.makeText(getContext(), getContext().getResources().getString(R.string.warrning_error), Toast.LENGTH_SHORT).show();
            }
        });


//        StringRequest request = new StringRequest(Request.Method.POST, App.READ_OBJECT_URI,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        progBar.setVisibility(View.INVISIBLE);
//                        objectList = JsonParserForObject.getObjectList(response);
//                        showList();
//                    }
//                }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                progBar.setVisibility(View.INVISIBLE);
//                Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
//            }
//        });
//        app.getRequestQueue().add(request);
    }

    private void showList() {
        adapter = new ObjectListAdapter(getContext(), getActivity(), objectList, new ObjectListAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(ObjectInfo objectInfo) {
                Intent intent = new Intent(getContext(), ObjectInformation.class);
                intent.putExtra("objectInfo", objectInfo);
                startActivity(intent);
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        recyclerView.addItemDecoration(new MyItemDecoration(getContext(), LinearLayoutManager.VERTICAL));
        recyclerView.setAdapter(adapter);
    }
}
