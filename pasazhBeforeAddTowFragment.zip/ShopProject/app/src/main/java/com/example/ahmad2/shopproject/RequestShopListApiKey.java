package com.example.ahmad2.shopproject;

import java.util.List;

public class RequestShopListApiKey {

    public Shop shop;
    public ApiKey apiKey=new ApiKey();

}
