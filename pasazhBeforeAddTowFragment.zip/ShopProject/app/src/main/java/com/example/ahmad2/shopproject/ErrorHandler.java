package com.example.ahmad2.shopproject;

import java.io.IOException;
import java.lang.annotation.Annotation;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.ResponseBody;
import retrofit2.Converter;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ErrorHandler {

    private Retrofit retrofit;

    public ErrorHandler(Retrofit retrofit){
        this.retrofit=retrofit;
    }
    public Error parseError(Response response){
        Converter<ResponseBody,Error> converter=retrofit.responseBodyConverter(Error.class,new Annotation[0]);
        Error error=null;
        try {
            error=converter.convert(response.errorBody());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return error;
    }


}
