package com.example.ahmad2.shopproject;

import java.util.List;

public class ResponseRegisterListToken {

    public List<Register> registerList;
    public String message;
    public String token;
}
