package com.example.ahmad2.shopproject;

public class RequestUserEditForAdmin {

    public String user;
    public String userSel;
    public short admin=0;
    public ApiKey apiKey=new ApiKey();
}
