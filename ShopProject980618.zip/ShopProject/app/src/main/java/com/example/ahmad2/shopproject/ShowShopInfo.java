package com.example.ahmad2.shopproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

public class ShowShopInfo extends AppCompatActivity {

    private TextView txtName,txtShop,txtJob,txtMobile,txtPhone,txtAddress;
    private Shop shop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_shop_info);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setView();
        if (getIntent().getParcelableExtra("shop")!=null) {
            shop = new Shop();
            shop=getIntent().getParcelableExtra("shop");
        }

        fullView();

    }

    private void fullView() {
        txtName.setText(shop.getName());
        txtShop.setText(shop.getShop());
        txtJob.setText(shop.getJob());
        txtMobile.setText(shop.getMobile());
        txtPhone.setText(shop.getPhone());
        txtAddress.setText(shop.getAddress());
    }

    private void setView() {
        txtName=findViewById(R.id.txt_name_show_shop_info);
        txtShop=findViewById(R.id.txt_shop_show_shop_info);
        txtJob=findViewById(R.id.txt_job_show_shop_info);
        txtMobile=findViewById(R.id.txt_mobile_show_shop_info);
        txtPhone=findViewById(R.id.txt_phone_show_shop_info);
        txtAddress=findViewById(R.id.txt_address_show_shop_info);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
