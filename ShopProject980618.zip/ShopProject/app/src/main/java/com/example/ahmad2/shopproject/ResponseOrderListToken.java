package com.example.ahmad2.shopproject;

import java.util.List;

class ResponseOrderListToken {

    public List<Order> orderList;
    public String message;
    public String token;
}
