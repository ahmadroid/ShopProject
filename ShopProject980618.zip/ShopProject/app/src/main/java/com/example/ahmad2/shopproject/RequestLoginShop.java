package com.example.ahmad2.shopproject;

public class RequestLoginShop {

    public Login login;
    public Shop shop;
}
