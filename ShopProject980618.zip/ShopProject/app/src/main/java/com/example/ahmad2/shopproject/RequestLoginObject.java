package com.example.ahmad2.shopproject;

public class RequestLoginObject {

    public Login login;
    public ObjectInfo objectInfo;
}
