package com.example.ahmad2.shopproject;

import java.util.ArrayList;
import java.util.List;

public class ResponseShopListToken {

    public List<Shop> shopList=new ArrayList<>();
    public String token;
    public String message;
}
