package com.example.ahmad2.shopproject;

public class Note {

    /*
    database for type of ObjectInfo
    screen for small and large screen
    multitab for show information
    request admin
     */
}
