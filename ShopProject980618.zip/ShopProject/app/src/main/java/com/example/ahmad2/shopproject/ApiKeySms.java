package com.example.ahmad2.shopproject;

public class ApiKeySms {

    public String apiKey;
    public String secretKey;

    public ApiKeySms(){
        this.secretKey="Ahmad912@5#0%8!42**";
        this.apiKey="321d42b819a8fdaf22293679";
    }
}
