package com.example.ahmad2.shopproject;

public class Login {
    public String user;
    public String pass;
    public ApiKey apiKey=new ApiKey();
}
