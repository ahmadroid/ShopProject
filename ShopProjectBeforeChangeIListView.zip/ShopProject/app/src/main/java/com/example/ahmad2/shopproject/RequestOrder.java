package com.example.ahmad2.shopproject;

public class RequestOrder {

    public Order order;
    public ApiKey apiKey=new ApiKey();
}
