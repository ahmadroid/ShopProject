package com.example.ahmad2.shopproject;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class FragmentUserForAdmin extends Fragment {

    private String user;
//    private String userName;
    private ViewPager viewPager;
    private List<Fragment> fragmentList;
    private List<String> titleList;
    private FragmentAdapter adapter;
    private TabLayout tabLayout;
    private SharedPreferences preference;
//    private String mobile;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getPreference();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.layout_fragment_user_for_admin,container,false);
        viewPager = view.findViewById(R.id.pager_fragment_user_for_admin);
        tabLayout = view.findViewById(R.id.tab_fragment_user_for_admin);
        fragmentList = new ArrayList<>();
        titleList = new ArrayList<>();

        FragmentOrderForUser fragmentOrderForUser = FragmentOrderForUser.newInstance(user);
        App.fragmentOrderForUser = fragmentOrderForUser;
        FragmentObjectListForUser fragmentObjectListForUser = FragmentObjectListForUser.newInstance(user, fragmentOrderForUser);
        App.fragmentObjectListForUser=fragmentObjectListForUser;
        fragmentList.add(fragmentObjectListForUser);
        titleList.add(getString(R.string.title_tab_object_list));
        fragmentList.add(fragmentOrderForUser);
        titleList.add(getString(R.string.title_tab_order_user));
        FragmentShopList fragmentShopList=new FragmentShopList();
        App.fragmentShopList=fragmentShopList;
        fragmentList.add(fragmentShopList);
        titleList.add(getString(R.string.title_tab_shop_list));
        adapter = new FragmentAdapter(getFragmentManager(), fragmentList, titleList);
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
        //tabLayout.getTabAt(0).setIcon(ContextCompat.getDrawable(this, R.drawable.ic_object));
//        tabLayout.getTabAt(0).setIcon(getResources().getDrawable(R.drawable.ic_object));
//        tabLayout.getTabAt(1).setIcon(ContextCompat.getDrawable(this, R.drawable.ic_order));
        return view;
    }

    private void getPreference() {
        preference = getContext().getSharedPreferences("userInfoPre", Context.MODE_PRIVATE);
        if (preference != null) {
            user = preference.getString("user", "");
//            userName = preference.getString("name", "");
//            mobile = preference.getString("mobile", "");
        }
    }
}
