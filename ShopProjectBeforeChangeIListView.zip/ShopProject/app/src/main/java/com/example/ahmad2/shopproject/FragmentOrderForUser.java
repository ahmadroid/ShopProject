package com.example.ahmad2.shopproject;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class FragmentOrderForUser extends Fragment {

    private RecyclerView recyclerView;
    private List<Order> orderList;
    private OrderListUserAdapter adapter;
    private ProgressBar progBar;
    private App app;
    private String user;
    private String token;
    private SharedPreferences preferences;

    public static FragmentOrderForUser newInstance(String user) {
        FragmentOrderForUser fragmentOrderForUser = new FragmentOrderForUser();
        Bundle arg = new Bundle();
        arg.putString("user", user);
        fragmentOrderForUser.setArguments(arg);
        return fragmentOrderForUser;
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferences=getContext().getSharedPreferences("userInfoPre",Context.MODE_PRIVATE);
        if (preferences!=null) {
            user = preferences.getString("user", "");
            token = preferences.getString("token", "");
        }
        app = new App(getContext());
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.layout_order_list_for_user, container, false);
        recyclerView = view.findViewById(R.id.recycler_order_list_for_user);
        progBar = view.findViewById(R.id.prog_order_list_for_user);
        getOrderList();
        return view;
    }

    public void getOrderList() {
        progBar.setVisibility(View.VISIBLE);
        OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder();
        clientBuilder.addInterceptor(new Interceptor() {
            @Override
            public okhttp3.Response intercept(Chain chain) throws IOException {
                okhttp3.Request orginal = chain.request();
                okhttp3.Request request = orginal.newBuilder()
                        .addHeader("Content-Type", "application/json")
                        .addHeader("shop-token", token)
                        .build();
                return chain.proceed(request);
            }
        });
        OkHttpClient client = clientBuilder.build();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(App.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(client)
                .build();
        RetrofitService retrofitService = retrofit.create(RetrofitService.class);
        Login login = new Login();
        login.user = user;
        Call<ResponseOrderListToken> call = retrofitService.getOrderListForUser(login);
        call.enqueue(new Callback<ResponseOrderListToken>() {
            @Override
            public void onResponse(Call<ResponseOrderListToken> call, retrofit2.Response<ResponseOrderListToken> response) {
                progBar.setVisibility(View.INVISIBLE);
                if (response.isSuccessful()) {
                    SharedPreferences.Editor editor=preferences.edit();
                    editor.putString("token",response.body().token);
                    editor.apply();
                    orderList = response.body().orderList;
                    showList();
                }
            }

            @Override
            public void onFailure(Call<ResponseOrderListToken> call, Throwable t) {
                progBar.setVisibility(View.INVISIBLE);
                Toast.makeText(getContext(), getContext().getResources().getString(R.string.warrning_error), Toast.LENGTH_SHORT).show();
            }
        });









//        StringRequest orderRequest = new StringRequest(Request.Method.POST, App.READ_ORDER_LIST_FOR_USER_URI,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        progBar.setVisibility(View.INVISIBLE);
//                        orderList = JsonParserForOrder.getOrderList(response);
//                        showList();
//                    }
//                }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                progBar.setVisibility(View.INVISIBLE);
//                Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
//            }
//        }) {
//            @Override
//            protected Map<String, String> getParams() throws AuthFailureError {
//                Map<String, String> params = new HashMap<>();
//                params.put("user", user);
//                return params;
//            }
//        };
//        app.getRequestQueue().add(orderRequest);
    }

    private void showList() {
        adapter = new OrderListUserAdapter(getContext(), orderList, new OrderListUserAdapter.OnItemClickListener() {
            @Override
            public void onItemclick(final Order order) {
                Intent intent=new Intent(getContext(),OrderPageForUser.class);
                intent.putExtra("order",order);
                startActivity(intent);
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.addItemDecoration(new MyItemDecoration(getContext(), LinearLayoutManager.VERTICAL));
        recyclerView.setAdapter(adapter);
    }

    private void changeSize(Window window) {
        Point size = new Point();
        if (getActivity() != null)
            getActivity().getWindowManager().getDefaultDisplay().getSize(size);
        window.setLayout(size.x,ViewGroup.LayoutParams.WRAP_CONTENT);
    }


}
