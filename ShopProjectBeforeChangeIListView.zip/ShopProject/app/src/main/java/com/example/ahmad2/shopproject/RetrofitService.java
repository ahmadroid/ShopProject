package com.example.ahmad2.shopproject;

import android.util.Log;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.HTTP;
import retrofit2.http.POST;
import retrofit2.http.PUT;

public interface RetrofitService {

    @POST("readuserpassfromdb.php")
    Call<User> getUser(@Body Login login);

    @POST("insertuserpasstodb.php")
    Call<ResponseMessageToken> insertUser(@Body RequestUserApiKey requestUserApiKey);

    @POST("editpassfromdb.php")
    Call<ResponseMessageToken> editPass(@Body Login login);

    @HTTP(method = "DELETE",path = "deleteuserforadmin.php",hasBody = true)
    Call<ResponseMessageToken> deleteUser(@Body RequestUserEditForAdmin requestUserEditForAdmin);

    @PUT("updateuserforadmin.php")
    Call<ResponseMessageToken> updateSeen(@Body RequestUserEditForAdmin requestUserEditForAdmin);

    @PUT("updateusertodb.php")
    Call<ResponseMessageToken> updateUserInformation(@Body RequestUserApiKey requestUserApiKey);

    @POST("sendsmsforrecovery.php")
    Call<ResponseMessageToken> sendSmsRecovery(@Body PanelInfo panelInfo);

    @POST("readuserforadmin.php")
    Call<ResponseUserListToken> getUserListForAdmin(@Body Login login);

    @POST("searchregisterfromdb.php")
    Call<ResponseRegisterListToken> searchRegisterListForAdmin(@Body RequestUserEditForAdmin requestUserEditForAdmin);
// insert
    @POST("insertobjecttodb.php")
    Call<ResponseMessageToken> insertObject(@Body RequestObjectApiKey requestObjectApiKey);

    @POST("insertorderusertodb.php")
    Call<ResponseMessageToken> insertOrder(@Body RequestOrder requestOrder);

    @PUT("updateobjectindb.php")
    Call<ResponseMessageToken> updateObject(@Body RequestObjectApiKey requestObjectApiKey);

    @HTTP(method = "DELETE",path = "deleteobjectfromdb.php",hasBody = true)
    Call<ResponseMessageToken> deleteObject(@Body RequestObjectApiKey requestObjectApiKey);

    @POST("readobjectforuser.php")
    Call<ResponseObjectListToken> getObjectListForUser(@Body Login login);

    @POST("readobjectforadmin.php")
    Call<ResponseObjectListToken> getObjectListForAdmin(@Body Login login);

    @POST("searchobjectforuser.php")
    Call<ResponseObjectListToken> getObjectListBySearchForuUser(@Body Login login);

    @POST("searchobjectforadmin.php")
    Call<ResponseObjectListToken> getObjectListBySearchForAdmin(@Body Login login);

    @POST("readorderforuser.php")
    Call<ResponseOrderListToken> getOrderListForUser(@Body Login login);

    @POST("readorderforadmin.php")
    Call<ResponseOrderListToken> getOrderListForAdmin(@Body Login login);

    @POST("searchorderuserforadmin.php")
    Call<ResponseOrderListToken> getOrderListForAdminBySearch(@Body RequestUserEditForAdmin requestUserEditForAdmin);

    @PUT("updateorder.php")
    Call<ResponseMessageToken> updateOrder(@Body RequestOrder requestOrder);

    @HTTP(method = "DELETE",path = "deleteorderfromdb.php",hasBody = true)
    Call<ResponseMessageToken> deleteOrder(@Body RequestOrder requestOrder);

    @PUT("updateseen.php")
    Call<ResponseMessageToken> updateSeen(@Body RequestOrder requestOrder);


    @POST("insertshoptodb.php")
    Call<ResponseMessageToken> insertShop(@Body RequestShopApiKey requestShopApiKey);

    @POST("readshoplistfromdb.php")
    Call<ResponseShopListToken> getShopList(@Body Login login);

    @PUT("updateshopinfotodb.php")
    Call<ResponseMessageToken> updateShopInfo(@Body RequestShopApiKey requestShopApiKey);

    @POST("SendSmsForRegister.php")
    Call<ResponseMessageToken> sendSmsRegister(@Body PanelInfo panelInfo);

    @POST("registeruser.php")
    Call<ResponseMessageToken> newRegister(@Body Login login);

    @POST("readregisterforadmin.php")
    Call<ResponseRegisterListToken> getRegisteList(@Body Login login);

    @POST("searchshopfromdb.php")
    Call<ResponseShopListToken> getShopListBySearch(@Body Login login);

    @POST("authorization.php")
    Call<ResponseMessageToken> authorization(@Body Login login);

}
