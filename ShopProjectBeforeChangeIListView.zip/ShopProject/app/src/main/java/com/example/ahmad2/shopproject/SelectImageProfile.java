package com.example.ahmad2.shopproject;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.textclassifier.TextClassification;
import android.widget.Button;
import android.widget.ImageView;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.transform.Result;

public class SelectImageProfile extends MyActivity {

    private ImageView imgProfile;
    private Button btnProfile;
    private static final int REQ_CODE=10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_image_profile);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        btnProfile=findViewById(R.id.btn_profile);
        imgProfile=findViewById(R.id.img_profile);
        File subDir=new File(Environment.getExternalStorageDirectory(),"ShopDirPic");
        File file=new File(subDir,"myPic.jpg");
        if (file.exists()){
            try {
                FileInputStream fileInputStream=new FileInputStream(file);
                Bitmap bitmap=BitmapFactory.decodeStream(fileInputStream);
                imgProfile.setImageBitmap(bitmap);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        btnProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent,10);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==REQ_CODE && resultCode==RESULT_OK){
            try {
                Uri imageUri = data.getData();
                imgProfile.setImageURI(imageUri);
                InputStream inputStream = getContentResolver().openInputStream(imageUri);
                File subDir=new File(Environment.getExternalStorageDirectory(),"ShopDirPic");
                File file=new File(subDir,"myPic.jpg");
                FileOutputStream fileOutputStream=new FileOutputStream(file);
                BufferedInputStream buffer=new BufferedInputStream(inputStream);
                byte[] bytes=new byte[1024];
                int count=0;
                while ((count=buffer.read(bytes))!=-1){
                    fileOutputStream.write(bytes,0,count);
                }
                fileOutputStream.flush();
                fileOutputStream.close();
                buffer.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private Bitmap decodeUri(Uri imagePath) throws FileNotFoundException {

        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(getContentResolver().openInputStream(imagePath), null, o);

        final int REQUIRED_SIZE = 140;

        int width_tmp = o.outWidth, height_tmp = o.outHeight;
        int scale = 1;
        while (true) {
            if (width_tmp / 2 < REQUIRED_SIZE
                    || height_tmp / 2 < REQUIRED_SIZE) {
                break;
            }
            width_tmp /= 2;
            height_tmp /= 2;
            scale *= 2;
        }

        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = scale;
        return BitmapFactory.decodeStream(getContentResolver().openInputStream(imagePath), null, o2);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
