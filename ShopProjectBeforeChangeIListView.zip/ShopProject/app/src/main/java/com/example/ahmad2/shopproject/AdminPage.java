package com.example.ahmad2.shopproject;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class AdminPage extends MyActivity implements NavigationView.OnNavigationItemSelectedListener {

    private ViewPager viewPager;
    private FragmentAdapter adapter;
    private List<Fragment> fragmentList;
    private TabLayout tabLayout;
    private List<String> titleList;
    private Toolbar toolbar;
    private String user, userName;
    private AppCompatTextView txtNameHeader, txtEmailHeader;
    private ImageView imgHeader;
    private SharedPreferences prefUserInfo,prefShopInfo;
    private FragmentObjectListForAdmin fragmentObjectListForAdmin;
    private FragmentUserListForAdmin fragmentUserListForAdmin;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private String mobile;
    private Bitmap bitmap;
    private Shop shop;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_page);
//        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getPreference();
        toolbar =(Toolbar) findViewById(R.id.toolbar_admin_page);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle(getString(R.string.hello));
        toolbar.setSubtitle(getString(R.string.welcom_to_user));
        tabLayout = findViewById(R.id.tab_admin_page);
        fragmentList = new ArrayList<>();
        titleList = new ArrayList<>();
        viewPager = findViewById(R.id.pager_admin_page);
//        fragmentUserListForAdmin = new FragmentUserListForAdmin();
//        App.fragmentUserListForAdmin = fragmentUserListForAdmin;
//        fragmentList.add(fragmentUserListForAdmin);
//        titleList.add(getString(R.string.user_list));
//        fragmentObjectListForAdmin = new FragmentObjectListForAdmin();
//        App.fragmentObjectListForAdmin = fragmentObjectListForAdmin;
//        fragmentList.add(fragmentObjectListForAdmin);
//        titleList.add(getString(R.string.object_list));
//        fragmentList.add(FragmentInsertObject.newInstance(fragmentObjectListForAdmin));
//        titleList.add(getString(R.string.insert_object));
//        FragmentOrderForAdmin fragmentOrderForAdmin = new FragmentOrderForAdmin();
//        App.fragmentOrderForAdmin = fragmentOrderForAdmin;
//        fragmentList.add(fragmentOrderForAdmin);
//        titleList.add(getString(R.string.order_admin));
        FragmentMyShop fragmentMyShop=new FragmentMyShop();
        fragmentList.add(fragmentMyShop);
        titleList.add(getString(R.string.title_tab_myShop));
        FragmentUserForAdmin fragmentUserForAdmin=new FragmentUserForAdmin();
        fragmentList.add(fragmentUserForAdmin);
        titleList.add(getString(R.string.title_tab_user_for_admin));
        adapter = new FragmentAdapter(getSupportFragmentManager(), fragmentList, titleList);
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
//        tabLayout.getTabAt(0).setIcon(ContextCompat.getDrawable(this, R.drawable.ic_action_user));
//        tabLayout.getTabAt(1).setIcon(ContextCompat.getDrawable(this, R.drawable.ic_object));
//        tabLayout.getTabAt(2).setIcon(ContextCompat.getDrawable(this, R.drawable.ic_add));
//        tabLayout.getTabAt(3).setIcon(ContextCompat.getDrawable(this, R.drawable.ic_order));
//        Log.i("tagposition",String.valueOf(viewPager.getAdapter().getItemPosition(FragmentObjectListForAdmin.class)));
//                    case "اضافه کردن کالا": {
//                        FragmentInsertObject fragmentInsertObject = (FragmentInsertObject) viewPager.getAdapter().instantiateItem(viewPager, i);
//                        fragmentInsertObject.getSpinner();
//                    }
        drawerLayout =(DrawerLayout) findViewById(R.id.drawer_layout_adminPage);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_drawer, R.string.close_drawer);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView = (NavigationView) findViewById(R.id.navi_view_adminPage);
        navigationView.setNavigationItemSelectedListener(this);
        View headerView = navigationView.getHeaderView(0);
        txtEmailHeader = headerView.findViewById(R.id.txt_email_hedear);
        txtNameHeader = headerView.findViewById(R.id.txt_name_hedear);
        imgHeader = headerView.findViewById(R.id.img_header);
        imgHeader.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bitmap=getBitmap();
                if (bitmap!=null){
                    Dialog imgDialog=new Dialog(AdminPage.this);
                    imgDialog.setContentView(R.layout.layout_image_dialog);
                    changeSize(imgDialog.getWindow());
                    ImageView img=imgDialog.findViewById(R.id.img_dialog);
                    img.setImageBitmap(bitmap);
                    imgDialog.show();
                }
            }
        });
    }

    private void changeSize(Window window) {
        Point size=new Point();
        getWindowManager().getDefaultDisplay().getSize(size);
        window.setLayout((int)(size.x*0.8),(int)(size.y*0.5));
    }

    @Override
    protected void onResume() {
        super.onResume();
        setHeader();
    }

    private void setHeader() {
        getPreference();
        txtNameHeader.setText(user);
//        txtEmailHeader.setText(mobile);
        bitmap=getBitmap();
        if (bitmap != null) {
            imgHeader.setImageBitmap(bitmap);
        }
    }

    private Bitmap getBitmap() {
        Bitmap bmp;
        File subDir = new File(Environment.getExternalStorageDirectory(), "ShopDirPic");
        File file = new File(subDir, "myPic.jpg");
        if (file.exists()) {
            try {
                FileInputStream fileInputStream = new FileInputStream(file);
                bmp = BitmapFactory.decodeStream(fileInputStream);
                return bmp;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    private void getPreference() {
        prefUserInfo = getSharedPreferences("userInfoPre", MODE_PRIVATE);
        if (prefUserInfo !=null){
//            userName= prefUserInfo.getString("name","");
            user= prefUserInfo.getString("user","");
//            mobile= prefUserInfo.getString("mobile","");
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout_adminPage);
        if (drawerLayout.isDrawerOpen(GravityCompat.START))
            drawerLayout.closeDrawer(GravityCompat.START);
        else {
            super.onBackPressed();
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.item_edit_pass_admin) {
//            Intent intent = new Intent(AdminPage.this, EditPassword.class);
//            startActivity(intent);
        } else if (id == R.id.item_info_admin) {
//            Intent intent = new Intent(AdminPage.this, EditUserInformationActivity.class);
//            startActivity(intent);
        } else if (id == R.id.item_exit_admin) {
            finish();
        }else if (id==R.id.item_select_pic_admin){
            Intent intent=new Intent(AdminPage.this,SelectImageProfile.class);
            startActivity(intent);
        }else if (id==R.id.item_edit_shop){
            Intent intent=new Intent(AdminPage.this,EditShopInformation.class);
            startActivity(intent);
        }
        DrawerLayout drawerLayout =(DrawerLayout) findViewById(R.id.drawer_layout_adminPage);
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}
