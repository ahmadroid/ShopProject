package com.example.ahmad2.shopproject;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.SerializedName;

public class ObjectInfo implements Parcelable{

    private long codeObject;
    private String name;
    private String user;
    private int price;
    private String description;
    @SerializedName("image")
    private short isImageSelect;

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public short getIsImageSelect() {
        return isImageSelect;
    }

    public void setIsImageSelect(short isImageSelect) {
        this.isImageSelect = isImageSelect;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public ObjectInfo(){ }

    public long getCodeObject(){
        return this.codeObject;
    }

    public void setCodeObject(long codeObject){
        this.codeObject = codeObject;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return name;
    }

    public ObjectInfo(Parcel parcel){
        this.codeObject =parcel.readLong();
        this.name=parcel.readString();
        this.price=parcel.readInt();
        this.isImageSelect= (short) parcel.readInt();
        this.user=parcel.readString();
        this.description=parcel.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(codeObject);
        dest.writeString(name);
        dest.writeInt(price);
        dest.writeInt(isImageSelect);
        dest.writeString(user);
        dest.writeString(description);
    }

    public static final Creator<ObjectInfo> CREATOR=new Creator<ObjectInfo>() {
        @Override
        public ObjectInfo createFromParcel(Parcel source) {
            return new ObjectInfo(source);
        }

        @Override
        public ObjectInfo[] newArray(int size) {
            return new ObjectInfo[size];
        }
    };
}
