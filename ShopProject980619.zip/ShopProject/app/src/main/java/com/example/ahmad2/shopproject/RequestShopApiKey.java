package com.example.ahmad2.shopproject;

import java.util.List;

public class RequestShopApiKey {

    public Shop shop;
    public ApiKey apiKey=new ApiKey();

}
