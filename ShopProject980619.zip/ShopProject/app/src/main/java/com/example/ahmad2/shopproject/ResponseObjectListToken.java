package com.example.ahmad2.shopproject;

import java.util.List;

public class ResponseObjectListToken {

    public List<ObjectInfo> objectList;
    public String message;
    public String token;
}
