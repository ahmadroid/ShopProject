package com.example.ahmad2.shopproject;

import java.util.List;

public class ResponseUserListToken {

    public List<User> userList;
    public String message;
    public String token;
}
