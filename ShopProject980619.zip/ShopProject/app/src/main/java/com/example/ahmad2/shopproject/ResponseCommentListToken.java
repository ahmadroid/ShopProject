package com.example.ahmad2.shopproject;

import java.util.List;

class ResponseCommentListToken {

    public List<Comment> commentList;
    public String message;
    public String token;
}
