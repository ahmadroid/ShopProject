package com.example.ahmad2.shopproject;

public class ResponseTokenInformation {

    public String token;
    public Information information;
}
