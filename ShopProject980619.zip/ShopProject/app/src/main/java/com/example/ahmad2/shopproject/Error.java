package com.example.ahmad2.shopproject;

public class Error {

    public String type;
    public String description;
}
