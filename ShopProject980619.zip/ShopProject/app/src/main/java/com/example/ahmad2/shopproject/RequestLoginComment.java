package com.example.ahmad2.shopproject;

public class RequestLoginComment {

    public Login login;
    public Comment comment;
}
