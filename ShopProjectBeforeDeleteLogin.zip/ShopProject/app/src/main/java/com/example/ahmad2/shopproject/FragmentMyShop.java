package com.example.ahmad2.shopproject;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

public class FragmentMyShop extends Fragment {

    private ViewPager viewPager;
    private FragmentAdapter adapter;
    private List<Fragment> fragmentList;
    private TabLayout tabLayout;
    private List<String> titleList;
    private Toolbar toolbar;
    private String user, userName;
    private AppCompatTextView txtNameHeader, txtEmailHeader;
    private ImageView imgHeader;
    private SharedPreferences preferences;
    private FragmentObjectListForAdmin fragmentObjectListForAdmin;
    private FragmentUserListForAdmin fragmentUserListForAdmin;
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private String mobile;
    private Bitmap bitmap;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getPreference();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.layout_fragment_myshop,container,false);


        //        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        tabLayout = view.findViewById(R.id.tab_fragment_myshop);
        fragmentList = new ArrayList<>();
        titleList = new ArrayList<>();
        viewPager = view.findViewById(R.id.pager_fragment_myshop);
        fragmentUserListForAdmin = new FragmentUserListForAdmin();
        App.fragmentUserListForAdmin = fragmentUserListForAdmin;
        fragmentList.add(fragmentUserListForAdmin);
        titleList.add(getString(R.string.title_tab_user_list));
        fragmentObjectListForAdmin = new FragmentObjectListForAdmin();
        App.fragmentObjectListForAdmin = fragmentObjectListForAdmin;
        fragmentList.add(fragmentObjectListForAdmin);
        titleList.add(getString(R.string.title_tab_object_list));
        fragmentList.add(FragmentInsertObject.newInstance(fragmentObjectListForAdmin));
        titleList.add(getString(R.string.title_tab_insert_object));
        FragmentOrderForAdmin fragmentOrderForAdmin = new FragmentOrderForAdmin();
        App.fragmentOrderForAdmin = fragmentOrderForAdmin;
        fragmentList.add(fragmentOrderForAdmin);
        titleList.add(getString(R.string.title_tab_order_admin));
        adapter = new FragmentAdapter(getFragmentManager(), fragmentList, titleList);
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
//        tabLayout.getTabAt(0).setIcon(ContextCompat.getDrawable(this, R.drawable.ic_action_user));
//        tabLayout.getTabAt(1).setIcon(ContextCompat.getDrawable(this, R.drawable.ic_object));
//        tabLayout.getTabAt(2).setIcon(ContextCompat.getDrawable(this, R.drawable.ic_add));
//        tabLayout.getTabAt(3).setIcon(ContextCompat.getDrawable(this, R.drawable.ic_order));
//        Log.i("tagposition",String.valueOf(viewPager.getAdapter().getItemPosition(FragmentObjectListForAdmin.class)));
//                    case "اضافه کردن کالا": {
//                        FragmentInsertObject fragmentInsertObject = (FragmentInsertObject) viewPager.getAdapter().instantiateItem(viewPager, i);
//                        fragmentInsertObject.getSpinner();
//                    }


        return view;
    }

    private void getPreference() {
        preferences = getContext().getSharedPreferences("userInfoPre", Context.MODE_PRIVATE);
        if (preferences!=null){
            userName=preferences.getString("name","");
            user=preferences.getString("user","");
            mobile=preferences.getString("mobile","");
        }
    }
}
