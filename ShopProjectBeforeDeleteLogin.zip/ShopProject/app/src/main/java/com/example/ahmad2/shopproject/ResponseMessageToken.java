package com.example.ahmad2.shopproject;

public class ResponseMessageToken {

    public String message;
    public String token;
}
