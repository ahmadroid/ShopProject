package com.example.ahmad2.shopproject;

public class ApiKey {

    public String secretKey;
    public String apiKey;

    public ApiKey(){
        this.secretKey="Ahmad912kkksjhdshdj222kdksfdjflskldf@@@@@333444pppppppppppppppppppppp";
        this.apiKey="321d42b819a8fdaf22293679";
    }

}
