package com.example.ahmad2.shopproject;

import java.util.List;

public class ResponseShopListToken {

    public List<Shop> shopList;
    public String token;
    public String message;
}
